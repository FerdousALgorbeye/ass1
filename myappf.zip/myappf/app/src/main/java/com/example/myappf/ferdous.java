package com.example.myappf;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.widget.Button;

public class ferdous extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button schb = findViewById(R.id.searchButton);
        schb.setOnClickListener(v -> {
            Intent in = new Intent(ferdous.this, SearchActivity.class);
            startActivity(in);
        });
    }
}