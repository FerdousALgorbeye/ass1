package com.example.myappf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Spinner categorySpinner = findViewById(R.id.categorySpinner);
        EditText searchInput = findViewById(R.id.searchInput);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        CheckBox checkBox = findViewById(R.id.checkBox);
        Button searchButton = findViewById(R.id.searchButton);

        String[] categories = {"Exercise", "Diet Plan", "Sleep", "Mental Health", "Other"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // تحديد طريقة عرض البيانات عند التحديد
        categorySpinner.setAdapter(adapter);

        searchButton.setOnClickListener(v -> {
            Intent intent = new Intent(SearchActivity.this, ListActivity.class);
            startActivity(intent);
        });
    }
}
