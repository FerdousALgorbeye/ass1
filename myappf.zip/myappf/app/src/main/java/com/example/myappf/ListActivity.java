package com.example.myappf;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);  // تأكد من أن هذا هو اسم ملف XML الصحيح

        // البيانات الوهمية
        String[] data = {"Exercise 1", "Exercise 2", "Diet Plan 1", "Diet Plan 2"};

        // إعداد ListView
        ListView listView = findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);

        // التعامل مع النقر على العناصر في ListView
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String item = data[position];
            Toast.makeText(ListActivity.this, "Selected: " + item, Toast.LENGTH_SHORT).show();
        });
    }
}
